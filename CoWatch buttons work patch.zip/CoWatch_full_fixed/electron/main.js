
const { app, BrowserWindow, ipcMain, clipboard, shell } = require('electron');
const path = require('path');
const http = require('http');
const fs = require('fs');

async function waitForServer(baseUrl, timeoutMs = 30000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    try {
      await new Promise((res, rej) => {
        const req = http.get(`${baseUrl}/api/health`, r => {
          r.resume();
          (r.statusCode === 200) ? res() : rej(new Error(`HTTP ${r.statusCode}`));
        });
        req.on('error', rej);
      });
      return true;
    } catch {
      await new Promise(r => setTimeout(r, 400));
    }
  }
  return false;
}

function createWindow(loadedFromServer) {
  const win = new BrowserWindow({
    width: 1200, height: 820, show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false, contextIsolation: true
    }
  });
  win.on('ready-to-show', () => win.show());

  if (loadedFromServer) {
    win.loadURL('http://localhost:5757');
  } else {
    win.loadFile(path.join(__dirname, '..', 'app', 'index.html'));
  }
}

app.whenReady().then(async () => {
  // Use a writable media dir inside userData
  const userData = app.getPath('userData');
  const mediaDir = path.join(userData, 'media');
  try { fs.mkdirSync(mediaDir, { recursive: true }); } catch {}
  process.env.COWATCH_MEDIA_DIR = mediaDir;
  process.env.PORT = process.env.PORT || '5757';

  // Start the server in-process
  require(path.join(__dirname, '..', 'server', 'server.js'));

  const ok = await waitForServer('http://localhost:5757', 30000);
  createWindow(ok);
});

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

// IPC helpers
ipcMain.handle('copy-to-clipboard', (_evt, text) => { clipboard.writeText(text || ''); return true; });
ipcMain.handle('open-external', (_evt, url) => { if (url) shell.openExternal(url); return true; });
ipcMain.handle('set-open-at-login', (_evt, enabled) => {
  app.setLoginItemSettings({ openAtLogin: !!enabled });
  return app.getLoginItemSettings().openAtLogin;
});
ipcMain.handle('get-open-at-login', () => app.getLoginItemSettings().openAtLogin);
