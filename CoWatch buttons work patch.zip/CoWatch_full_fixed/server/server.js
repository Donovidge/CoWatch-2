
const express = require('express');
const path = require('path');
const http = require('http');
const { WebSocketServer } = require('ws');
const multer = require('multer');
const fs = require('fs');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');
const mime = require('mime');
const { spawn } = require('child_process');

let localtunnel = null;
try { localtunnel = require('localtunnel'); } catch {}

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 5757;
const PUBLIC_DIR = path.join(__dirname, '..', 'app');
const DEFAULT_MEDIA_DIR = path.join(__dirname, '..', 'media');
const MEDIA_DIR = process.env.COWATCH_MEDIA_DIR || DEFAULT_MEDIA_DIR;
try { fs.mkdirSync(MEDIA_DIR, { recursive: true }); } catch {}

const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });

const rooms = new Map();
let tunnel = null;

// Attempt firewall rule (best-effort)
(function tryOpenFirewall(){
  if (process.platform !== 'win32') return;
  try {
    const cmd = `netsh advfirewall firewall add rule name="CoWatch 5757" dir=in action=allow protocol=TCP localport=${PORT}`;
    const child = spawn('cmd.exe', ['/c', cmd], { windowsHide: true });
    child.on('close', ()=>{});
  } catch {}
})();

app.get('/api/health', (_req,res)=>{
  res.json({ ok:true, port: PORT, rooms: rooms.size, tunnel: tunnel ? tunnel.url : null, mediaDir: MEDIA_DIR });
});

// Rooms
app.get('/api/rooms', (_req, res) => {
  const list = Array.from(rooms.entries()).map(([roomId, r]) => ({ roomId, createdAt:r.createdAt }));
  res.json(list);
});
app.post('/api/createRoom', (req,res)=>{
  const { roomId, pin } = req.body || {};
  if (!roomId || !pin) return res.status(400).json({ error:'Missing roomId or pin' });
  if (!rooms.has(roomId)) rooms.set(roomId, { pin:String(pin), clients:new Set(), createdAt: Date.now() });
  res.json({ ok:true, roomId });
});
app.post('/api/joinRoom', (req,res)=>{
  const { roomId, pin } = req.body || {};
  const room = rooms.get(roomId);
  if (!room) return res.status(404).json({ error:'Room not found' });
  if (String(room.pin) !== String(pin)) return res.status(403).json({ error:'Invalid PIN' });
  res.json({ ok:true });
});

// File hosting
const storage = multer.diskStorage({
  destination: (_req,_file,cb)=> cb(null, MEDIA_DIR),
  filename: (_req,file,cb)=> {
    const ext = path.extname(file.originalname) || '.' + (mime.getExtension(file.mimetype) || 'bin');
    cb(null, `${uuidv4()}${ext}`);
  }
});
const upload = multer({ storage });
app.post('/api/upload', upload.single('video'), (req,res)=>{
  if (!req.file) return res.status(400).json({ error:'No file' });
  res.json({ ok:true, url: `/media/${path.basename(req.file.path)}` });
});

// Tunnel endpoints
app.post('/api/startTunnel', async (_req,res)=>{
  if (!localtunnel) return res.status(500).json({ ok:false, error:'Localtunnel module missing' });
  if (tunnel) return res.json({ ok:true, url: tunnel.url });
  try {
    tunnel = await localtunnel({ port: PORT });
    tunnel.on('close', ()=> { tunnel = null; });
    res.json({ ok:true, url: tunnel.url });
  } catch (e) {
    res.status(500).json({ ok:false, error: e.message });
  }
});
app.post('/api/stopTunnel', (_req,res)=>{
  try { if (tunnel) tunnel.close(); } catch {}
  tunnel = null; res.json({ ok:true });
});

// Static
app.use('/media', express.static(MEDIA_DIR, { maxAge: 0 }));
app.use('/', express.static(PUBLIC_DIR, { maxAge: 0 }));

// Signaling
wss.on('connection', (ws) => {
  ws.id = uuidv4();
  ws.roomId = null; ws.username = null;

  ws.on('message', (msg)=>{
    let data={}; try{ data = JSON.parse(msg.toString()); }catch{}
    const { type } = data;
    if (type === 'join') {
      const { roomId, pin, username } = data;
      const room = rooms.get(roomId);
      if (!room) return ws.send(JSON.stringify({ type:'error', error:'Room not found' }));
      if (String(room.pin) !== String(pin)) return ws.send(JSON.stringify({ type:'error', error:'Invalid PIN' }));
      ws.roomId = roomId; ws.username = username || 'Guest';
      room.clients.add(ws);
      for (const c of room.clients) c.send(JSON.stringify({ type:'presence', id:ws.id, username:ws.username, joined:true }));
      ws.send(JSON.stringify({ type:'roster', roster: Array.from(room.clients).map(c=>({id:c.id,username:c.username})) }));
      return;
    }
    if (type === 'leave') {
      if (ws.roomId && rooms.has(ws.roomId)) {
        const room = rooms.get(ws.roomId);
        room.clients.delete(ws);
        for (const c of room.clients) c.send(JSON.stringify({ type:'presence', id:ws.id, username:ws.username, joined:false }));
      }
      ws.roomId = null; return;
    }
    // Relay any other message to peers in the room
    if (ws.roomId && rooms.has(ws.roomId)) {
      const room = rooms.get(ws.roomId);
      for (const c of room.clients) if (c!==ws && c.readyState===1) c.send(JSON.stringify({ ...data, from: ws.id, username: ws.username }));
    }
  });

  ws.on('close', ()=>{
    if (ws.roomId && rooms.has(ws.roomId)) {
      const room = rooms.get(ws.roomId);
      room.clients.delete(ws);
      for (const c of room.clients) c.send(JSON.stringify({ type:'presence', id:ws.id, username:ws.username, joined:false }));
      setTimeout(()=>{ if (room.clients.size===0) rooms.delete(ws.roomId); }, 10*60*1000);
    }
  });
});

server.listen(PORT, ()=> console.log(`CoWatch ready at http://localhost:${PORT} (media: ${MEDIA_DIR})`));
