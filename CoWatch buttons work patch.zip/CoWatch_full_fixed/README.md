
# CoWatch — Full Fixed Build

Included fixes:
- Start server in-process and **wait** for it before showing the window.
- Use a **writable media directory** in Electron userData (so uploads work when packaged).
- `.hidden{display:none !important}` so modals close properly.
- **Video source sync** (peer auto-loads uploaded video) + play/pause/seek sync.
- **Browser screen-share fallback** using `getDisplayMedia` when Electron APIs are unavailable.
- NSIS installer + portable build.

Build:
1) `npm install`
2) `npm run dist`
Installer + portable exe will be in `dist/`.
