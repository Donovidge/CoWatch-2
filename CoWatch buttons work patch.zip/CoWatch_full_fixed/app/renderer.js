
const $ = (sel) => document.querySelector(sel);
const serverOrigin = window.location.origin;
const wsUrl = serverOrigin.replace(/^http/,'ws') + '/ws';
const isElectron = !!window.electronAPI;

// State
let socket, roomId=null, pin=null, username=null, isConnected=false;
let peer, dataChannel;
let makingOffer=false, ignoreOffer=false, isPolite=false;
let localStream=null, canvasStream=null;
let pickedSourceId=null;

// Prefs
const prefs = {
  name: localStorage.getItem('cw_name') || '',
  autoTunnel: localStorage.getItem('cw_autoTunnel') === '1'
};

// Settings modal
$('#btnSettings').onclick = async () => {
  $('#setName').value = prefs.name || '';
  $('#setAutoTunnel').checked = !!prefs.autoTunnel;
  try { $('#setLoginStart').checked = isElectron ? await window.electronAPI.getOpenAtLogin() : false; } catch { $('#setLoginStart').checked = false; }
  $('#settings').classList.remove('hidden');
};
$('#btnCloseSettings').onclick = () => $('#settings').classList.add('hidden');
$('#btnSaveSettings').onclick = async () => {
  prefs.name = $('#setName').value.trim() || prefs.name || `User-${Math.random().toString(36).slice(2,6)}`;
  prefs.autoTunnel = $('#setAutoTunnel').checked;
  localStorage.setItem('cw_name', prefs.name);
  localStorage.setItem('cw_autoTunnel', prefs.autoTunnel ? '1' : '0');
  if (isElectron) await window.electronAPI.setOpenAtLogin($('#setLoginStart').checked);
  $('#settings').classList.add('hidden');
  $('#username').value = prefs.name;
};

// Rooms
async function refreshRooms() {
  try {
    const res = await fetch('/api/rooms');
    const list = await res.json();
    const sel = $('#roomSelect'); sel.innerHTML = '';
    for (const r of list) {
      const opt = document.createElement('option');
      opt.value = r.roomId; opt.textContent = r.roomId;
      sel.appendChild(opt);
    }
  } catch {}
}
$('#btnRefresh').onclick = refreshRooms;

function showRoomUI(show) {
  $('#access').classList.toggle('hidden', show);
  $('#room').classList.toggle('hidden', !show);
  $('#inviteRow').classList.toggle('hidden', !show);
}

// Create / Join
$('#btnCreate').onclick = async () => {
  const r = $('#createRoomId').value.trim() || Math.random().toString(36).slice(2,10);
  const p = $('#createPin').value.trim() || '1234';
  const resp = await fetch('/api/createRoom', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ roomId:r, pin:p }) });
  const json = await resp.json();
  if (!json.ok) return alert(json.error || 'Create failed');
  roomId = r; pin = p; username = prefs.name || `Host-${Math.random().toString(36).slice(2,6)}`;
  $('#roomLabel').textContent = roomId;
  showRoomUI(true);
  setupSocket();
  if (prefs.autoTunnel) startTunnel();
};
$('#btnJoin').onclick = async () => {
  const r = $('#roomSelect').value.trim();
  const p = $('#joinPin').value.trim();
  const u = $('#username').value.trim() || prefs.name || `User-${Math.random().toString(36).slice(2,6)}`;
  const resp = await fetch('/api/joinRoom', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ roomId:r, pin:p }) });
  const json = await resp.json();
  if (!json.ok) return alert(json.error || 'Join failed');
  roomId = r; pin = p; username = u; isPolite = true;
  $('#roomLabel').textContent = roomId;
  showRoomUI(true);
  setupSocket();
};

// Invite & Tunnel
$('#btnCopyInvite').onclick = async () => {
  if (!roomId || !pin) return alert('Create or join a room first');
  const health = await (await fetch('/api/health')).json();
  const base = health.tunnel || location.origin;
  const url = `${base}/?room=${encodeURIComponent(roomId)}&pin=${encodeURIComponent(pin)}`;
  const ok = isElectron ? await window.electronAPI.copyToClipboard(url) : copyFallback(url);
  $('#inviteCopied').textContent = ok ? 'Invite copied!' : 'Copy failed';
  setTimeout(()=> $('#inviteCopied').textContent = '', 2000);
};
function copyFallback(text){ try{ navigator.clipboard.writeText(text); return true; } catch { return false; } }
async function startTunnel() {
  try {
    const res = await fetch('/api/startTunnel', { method:'POST' });
    const json = await res.json();
    if (!json.ok) throw new Error(json.error || 'Could not start public link');
    $('#tunnelUrl').textContent = json.url;
    $('#tunnelUrl').onclick = () => isElectron ? window.electronAPI.openExternal(json.url) : (location.href = json.url);
  } catch (e) {
    alert('Public link error: ' + e.message);
  }
}
$('#btnStartTunnel').onclick = startTunnel;

// Socket & WebRTC
function setupSocket() {
  socket = new WebSocket(wsUrl);
  socket.onopen = () => {
    socket.send(JSON.stringify({ type:'join', roomId, pin, username }));
    isConnected = true;
    logSys(`Connected as ${username}`);
    ensurePeer();
    refreshHealth();
    // Handle invite auto-join via URL
    const params = new URLSearchParams(location.search);
    if (params.get('room') && !roomId) { /* not used here; host-only */ }
  };
  socket.onmessage = async (ev) => {
    const data = JSON.parse(ev.data);
    if (data.type==='error') return alert(data.error || 'Error');
    if (data.type==='presence') { logSys(`${data.username} ${data.joined?'joined':'left'}`); return; }
    if (data.type==='roster') return;
    if (data.type==='chat') { logChat(data.username || 'Peer', data.text); return; }
    if (data.type==='signal') { await onSignal(data); return; }
    if (data.type==='video-state') { onVideoState(data); return; }
    if (data.type==='video-source') { onVideoSource(data.url); return; }
  };
  socket.onclose = () => { isConnected = false; logSys('Disconnected'); };
}
function ensurePeer() {
  if (peer) return;
  peer = new RTCPeerConnection({ iceServers:[{urls:['stun:stun.l.google.com:19302','stun:global.stun.twilio.com:3478']}] });
  peer.onicecandidate = (e)=>{ if (e.candidate) socket?.send(JSON.stringify({ type:'signal', signalType:'candidate', candidate:e.candidate })); };
  peer.ontrack = (e)=> { $('#remoteVideo').srcObject = e.streams[0]; };
  const ch = peer.createDataChannel('chat');
  dataChannel = ch;
  ch.onopen = ()=> logSys('Chat ready');
  ch.onmessage = (e)=> {
    try {
      const msg = JSON.parse(e.data);
      if (msg.kind==='chat') logChat(msg.username||'Peer', msg.text);
      if (msg.kind==='video') onVideoState(msg);
      if (msg.kind==='video-source') onVideoSource(msg.url);
    } catch { logChat('Peer', e.data); }
  };
  peer.ondatachannel = (e)=> { e.channel.onmessage = ch.onmessage; };
  peer.onnegotiationneeded = async () => {
    try {
      makingOffer = true;
      await peer.setLocalDescription(await peer.createOffer());
      socket?.send(JSON.stringify({ type:'signal', signalType:'offer', sdp: peer.localDescription }));
    } finally { makingOffer = false; }
  };
}
async function onSignal({ signalType, sdp, candidate }) {
  ensurePeer();
  if (signalType==='offer') {
    const offerCollision = makingOffer || peer.signalingState !== 'stable';
    ignoreOffer = !isPolite && offerCollision;
    if (ignoreOffer) return;
    await peer.setRemoteDescription(sdp);
    await peer.setLocalDescription(await peer.createAnswer());
    socket?.send(JSON.stringify({ type:'signal', signalType:'answer', sdp: peer.localDescription }));
    return;
  }
  if (signalType==='answer') { await peer.setRemoteDescription(sdp); return; }
  if (signalType==='candidate') { try { await peer.addIceCandidate(candidate); } catch (e) { if (!ignoreOffer) throw e; } }
}

// Chat
function logChat(name, text){ const div=document.createElement('div'); div.innerHTML=`<b>${escapeHtml(name)}:</b> ${escapeHtml(text)}`; $('#chatLog').appendChild(div); $('#chatLog').scrollTop = $('#chatLog').scrollHeight; }
function logSys(text){ const div=document.createElement('div'); div.className='sys'; div.textContent=text; $('#chatLog').appendChild(div); $('#chatLog').scrollTop = $('#chatLog').scrollHeight; }
function escapeHtml(s){ return s.replace(/[&<>\"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
$('#btnSend').onclick = ()=> {
  const txt = $('#chatInput').value.trim(); if (!txt) return;
  $('#chatInput').value=''; logChat(username||'Me', txt);
  try { dataChannel?.send(JSON.stringify({ kind:'chat', username, text:txt })); } catch {}
  socket?.send(JSON.stringify({ type:'chat', text: txt }));
};

// Video hosting + source + sync
let fileToUpload=null; $('#filePicker').onchange=(e)=> fileToUpload = e.target.files?.[0] || null;
$('#btnUpload').onclick = async ()=>{
  if (!fileToUpload) return alert('Pick a video');
  const fd=new FormData(); fd.append('video', fileToUpload);
  const res=await fetch('/api/upload',{method:'POST', body:fd}); const json=await res.json();
  if (!json.ok) return alert(json.error||'Upload failed');
  const url=json.url; $('#videoUrlWrap').textContent = `${location.origin}${url}`;
  $('#video').src = url; await $('#video').load;
  broadcastVideoSource(url);
  logSys('Video hosted and shared with peer.');
};
function broadcastVideoSource(url){
  // Send over datachannel and WS, so either path works
  try { dataChannel?.send(JSON.stringify({ kind:'video-source', url })); } catch {}
  socket?.send(JSON.stringify({ type:'video-source', url }));
}
function onVideoSource(url){
  if (!url) return;
  $('#video').src = url;
  $('#video').load();
  logSys('Video source set by peer.');
}
$('#btnPlay').onclick = ()=> sendVideoState('play');
$('#btnPause').onclick = ()=> sendVideoState('pause');
$('#btnSync').onclick = ()=> sendVideoState('seek', $('#video').currentTime);
$('#video').onplay = ()=> sendVideoState('play');
$('#video').onpause = ()=> sendVideoState('pause');
$('#video').onseeked = ()=> sendVideoState('seek', $('#video').currentTime);
function sendVideoState(action, time){ const msg={ kind:'video', action, time }; try{ dataChannel?.send(JSON.stringify(msg)); }catch{} socket?.send(JSON.stringify({ type:'video-state', ...msg })); }
function onVideoState({action,time}){ const v=$('#video'); if (action==='play') v.play(); if (action==='pause') v.pause(); if (action==='seek'&&typeof time==='number') v.currentTime=time; }

// Screen share + crop with Electron and browser fallback
$('#btnPickSource').onclick = async ()=>{
  const wrap = $('#sources'); wrap.innerHTML='';
  if (isElectron) {
    const sources = await window.electronAPI.listScreenSources();
    for (const s of sources) {
      const div=document.createElement('div'); div.className='source';
      div.innerHTML = `<div>${s.name}</div>${s.thumbnailDataURL?`<img src="${s.thumbnailDataURL}">`:''}<button data-id="${s.id}">Select</button>`;
      wrap.appendChild(div);
    }
    wrap.querySelectorAll('button[data-id]').forEach(btn => {
      btn.onclick = async () => {
        pickedSourceId = btn.getAttribute('data-id');
        const stream = await window.electronAPI.getDisplayMediaBySourceId(pickedSourceId);
        $('#sharePreview').srcObject = stream; localStream = stream; enableCropDrawing();
      };
    });
  } else {
    // Browser fallback
    const info = document.createElement('div');
    info.className = 'muted small';
    info.textContent = 'Browser mode: use native picker when you click Start Full/Cropped Share.';
    wrap.appendChild(info);
  }
};
function ensureBrowserStream(){
  return navigator.mediaDevices.getDisplayMedia({ video:true, audio:false });
}
$('#btnStartShare').onclick = async ()=> {
  if (isElectron) {
    if (!localStream) return alert('Pick a source');
    addShareTrack(localStream.getVideoTracks()[0]);
  } else {
    const s = await ensureBrowserStream(); $('#sharePreview').srcObject = s; localStream = s; addShareTrack(s.getVideoTracks()[0]);
  }
};
$('#btnStartCropped').onclick = async ()=> {
  if (!$('#sharePreview').srcObject && !isElectron) {
    const s = await ensureBrowserStream(); $('#sharePreview').srcObject = s; localStream = s;
  }
  const video=$('#sharePreview'); const rect=$('#cropRect'); if (!video.srcObject) return alert('Pick a source');
  const renderCanvas=document.createElement('canvas'); const ctx=renderCanvas.getContext('2d');
  function step(){
    const vW=video.videoWidth||0, vH=video.videoHeight||0;
    if (vW && vH) {
      const wrapRect=document.querySelector('.crop-wrap').getBoundingClientRect();
      const videoRect=video.getBoundingClientRect();
      const rx=parseFloat(rect.style.left)||0, ry=parseFloat(rect.style.top)||0, rw=parseFloat(rect.style.width)||videoRect.width, rh=parseFloat(rect.style.height)||videoRect.height;
      const scaleX=vW / videoRect.width, scaleY=vH / videoRect.height;
      const sx=Math.max(0, Math.round((rx - (videoRect.left - wrapRect.left))*scaleX));
      const sy=Math.max(0, Math.round((ry - (videoRect.top - wrapRect.top))*scaleY));
      const sw=Math.max(1, Math.round(rw*scaleX)), sh=Math.max(1, Math.round(rh*scaleY));
      renderCanvas.width=sw; renderCanvas.height=sh; try{ ctx.drawImage(video, sx, sy, sw, sh, 0, 0, sw, sh); }catch{}
    }
    requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
  const stream=renderCanvas.captureStream(30); canvasStream=stream; addShareTrack(stream.getVideoTracks()[0]);
};
function addShareTrack(track){
  ensurePeer();
  peer.getSenders().filter(s=>s.track && s.track.kind==='video').forEach(s=>peer.removeTrack(s));
  const ms=new MediaStream(); ms.addTrack(track); ms.getTracks().forEach(t=>peer.addTrack(t, ms)); logSys('Sharing started');
}
$('#btnStopShare').onclick = ()=>{
  if(localStream){ localStream.getTracks().forEach(t=>t.stop()); localStream=null; }
  if(canvasStream){ canvasStream.getTracks().forEach(t=>t.stop()); canvasStream=null; }
  if(peer){ peer.getSenders().forEach(s=>{ if(s.track && s.track.kind==='video') peer.removeTrack(s); }); }
  $('#sharePreview').srcObject=null; logSys('Sharing stopped');
};
function enableCropDrawing(){
  const wrap = document.querySelector('.crop-wrap'); const video=$('#sharePreview'); const rect=$('#cropRect');
  let drawing=false, sx=0, sy=0, ex=0, ey=0;
  wrap.onmousedown = (e)=>{ drawing=true; const r=wrap.getBoundingClientRect(); sx=e.clientX-r.left; sy=e.clientY-r.top; rect.style.left=`${sx}px`; rect.style.top=`${sy}px`; rect.style.width='0px'; rect.style.height='0px'; rect.classList.remove('hidden'); };
  wrap.onmousemove = (e)=>{ if(!drawing) return; const r=wrap.getBoundingClientRect(); ex=e.clientX-r.left; ey=e.clientY-r.top; const x=Math.min(sx,ex),y=Math.min(sy,ey),w=Math.abs(ex-sx),h=Math.abs(ey-sy); rect.style.left=`${x}px`; rect.style.top=`${y}px`; rect.style.width=`${w}px`; rect.style.height=`${h}px`; };
  window.onmouseup = ()=> drawing=false;
}

// Leave
$('#btnLeave').onclick = ()=> {
  socket?.send(JSON.stringify({ type:'leave' })); socket?.close();
  try{ peer?.close(); }catch{} peer=null;
  roomId=pin=username=null; showRoomUI(false); refreshRooms();
};

// Health
async function refreshHealth(){
  try {
    const h = await (await fetch('/api/health')).json();
    $('#health').textContent = `Server port ${h.port} • Rooms: ${h.rooms} • Public: ${h.tunnel || 'off'}`;
  } catch {}
}

// Access bindings
$('#username').value = prefs.name || '';
refreshRooms();
